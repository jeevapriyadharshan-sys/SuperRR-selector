# SupeRR Selector S2 - Round 1: pressure model code

Place the supplied CSVs in /home/claude/data as: bbb1..bbb5.csv (ball_by_ball_part_1..5), matches.csv, comps.csv
(competitions), teams.csv, map.csv, xi.csv (paths are set at the top of each script; edit to your own folders).
Create /home/claude/out for outputs. Run in this order:

1. prep.py      clean data, build match state, exclusions (section 2)
1b. prep_truncation_filter.py  drop 15 matches with truncated innings (run right after prep.py)
2. model.py     win-probability + outcome models, leverage (section 3), 5-fold CV grouped by match
3. prep_rows.py per-ball value attribution (run-out rules etc.)
4. rating2.py   runs/wickets above expected, opponent adjustment, shrinkage, rating (section 4)
5. robust2.py   split-half, forward test, 200 bootstraps (seed 7), sensitivity (section 8)
6. final.py     final rankings at 200 pressure balls / 18 pressure innings; supporting stats
7. charts.py    figures

results/ holds the final top-10 lists and the full eligible-player tables.
Python 3.13, pandas, numpy, scikit-learn, scipy, matplotlib.
