import sys; sys.path.insert(0,"/home/claude/work")
import pandas as pd, numpy as np, pickle
from scipy.stats import spearmanr
import rating2 as R
rng=np.random.default_rng(7)
b0,thr=R.load(0.75); RB=R.build(b0)
mids=np.sort(b0.match_id.unique()); order=pd.Series(np.arange(len(mids)),index=mids)
res={}
for role,sgn in (('bat',-1),('bowl',1)):
    d=RB[role]; names=d.groupby('pid').name.last()
    main,_=R.rate(d,sgn); main['name']=names; top10=list(main.index[:10]); out={'main':main}
    NB=200; ranks=pd.DataFrame(index=main.index,columns=range(NB),dtype=float)
    for i in range(NB):
        cnt=rng.multinomial(len(mids),np.ones(len(mids))/len(mids)); w=dict(zip(mids,cnt))
        el,_=R.rate(d,sgn,w=w,min_hi=200*0.63,min_units=18*0.63)
        ix=main.index.intersection(el.index); ranks.loc[ix,i]=el.loc[ix,'rank'].values
    out['boot_top10']=(ranks<=10).sum(axis=1)/NB; out['boot_top5']=(ranks<=5).sum(axis=1)/NB
    out['boot_med']=ranks.median(axis=1); out['boot_q10']=ranks.quantile(.1,axis=1); out['boot_q90']=ranks.quantile(.9,axis=1)
    # split half: odd/even matches by chronological order
    dd=d.sort_values('date'); half=dd.match_id.map(order)%2
    hA,_=R.rate(dd[half==0],sgn,min_hi=75,min_units=7); hB,_=R.rate(dd[half==1],sgn,min_hi=75,min_units=7)
    cm=hA.index.intersection(hB.index)
    r=np.corrcoef(hA.loc[cm,'xH'],hB.loc[cm,'xH'])[0,1]
    out['split']=dict(n=len(cm),r_raw=r,sb=2*r/(1+r),r_L=np.corrcoef(hA.loc[cm,'L'],hB.loc[cm,'L'])[0,1],
        spearman_score=spearmanr(hA.loc[cm,'score'],hB.loc[cm,'score'])[0],
        r_baseline=np.corrcoef(hA.loc[cm,'xL'],hB.loc[cm,'xL'])[0,1],
        top10A_in_B_top30pct=float(np.mean([hB.loc[p,'rank']<=0.3*len(hB) for p in hA.index[:10] if p in hB.index])))
    # early-vs-late (first 60% of matches vs last 40%) predictive check
    cut=np.sort(mids)[int(0.6*len(mids))]
    e,_=R.rate(d[d.match_id<=cut],sgn,min_hi=100,min_units=10); l,_=R.rate(d[d.match_id>cut],sgn,min_hi=60,min_units=6)
    cm2=e.index.intersection(l.index)
    out['fwd']=dict(n=len(cm2),r=spearmanr(e.loc[cm2,'score'],l.loc[cm2,'score'])[0], top10_early_later_mean_pct=float(np.mean([l.loc[p,'rank']/len(l) for p in e.index[:10] if p in l.index])))
    sens={}
    for lab,kw in {'Level only':dict(weights=(1,0,0)),'Level+Consistency (0.67/0.33)':dict(weights=(.67,0,.33)),'Equal weights':dict(weights=(1/3,1/3,1/3)),'Min 150 pressure balls':dict(min_hi=150,min_units=15),'Min 300 pressure balls':dict(min_hi=300,min_units=25)}.items():
        el,_=R.rate(d,sgn,**kw); cmn=main.index.intersection(el.index)
        sens[lab]=(len(set(top10)&set(el.index[:10])),spearmanr(main.loc[cmn,'score'],el.loc[cmn,'score'])[0])
    for lab,q in {'Pressure = top 33% leverage':0.667,'Pressure = top 10% leverage':0.9}.items():
        bq,_=R.load(q); dq=R.build(bq)[role]
        el,_=R.rate(dq,sgn,min_hi=200 if q<.8 else 120,min_units=18 if q<.8 else 12); cmn=main.index.intersection(el.index)
        sens[lab]=(len(set(top10)&set(el.index[:10])),spearmanr(main.loc[cmn,'score'],el.loc[cmn,'score'])[0])
    dn=R.build(b0,adjust=False)[role]; el,_=R.rate(dn,sgn); cmn=main.index.intersection(el.index)
    sens['No opponent adjustment']=(len(set(top10)&set(el.index[:10])),spearmanr(main.loc[cmn,'score'],el.loc[cmn,'score'])[0])
    # IPL-only / T20I-only pressure sample
    for lab,ct in {'IPL balls only':[1],'T20I balls only':[0]}.items():
        el,_=R.rate(d[d.ctype.isin(ct)],sgn,min_hi=100,min_units=10); cmn=main.index.intersection(el.index)
        if len(cmn)>10: sens[lab]=(len(set(top10)&set(el.index[:10])),spearmanr(main.loc[cmn,'score'],el.loc[cmn,'score'])[0])
    out['sens']=sens
    hi=d[d.hi]; seas={}
    for p in top10:
        x=hi[hi.pid==p].groupby('season').agg(n=('net','size'),m=('net','mean')); x=x[x.n>=30]; seas[p]=(int((x.m>0).sum()),len(x))
    out['seasons']=seas
    # phase / innings split for top10: share of pressure balls & mean net by innings
    res[role]=out
    print(role,'split',out['split']); print(role,'fwd',out['fwd']); print(role,'sens',{k:(a,round(c,2)) for k,(a,c) in sens.items()})
pickle.dump(res,open('/home/claude/out/robust2.pkl','wb'))
for role in res:
    m=res[role]['main'].head(15).copy()
    for k in ('boot_top10','boot_top5','boot_med','boot_q10','boot_q90'): m[k]=res[role][k]
    print(role); print(m[['name','nH','score','boot_top5','boot_top10','boot_med','boot_q10','boot_q90']].round(2).to_string())
    print(res[role]['seasons'])
