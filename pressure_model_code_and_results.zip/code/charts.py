import pandas as pd, numpy as np, pickle, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#b8b7b0','axes.labelcolor':'#52514e','xtick.color':'#52514e','ytick.color':'#52514e','figure.facecolor':'white'})
BLUE,ORANGE,GRAY,INK='#2a78d6','#eb6834','#8a8984','#0b0b0b'
b=pd.read_pickle('/home/claude/out/rows.pkl'); fin,tabs,thr=pickle.load(open('/home/claude/out/final.pkl','rb')); rob=pickle.load(open('/home/claude/out/robust2.pkl','rb'))
b['hi']=b.li>=thr
out='/home/claude/out/charts/'
# ---- stats for text
S={}
S['thr']=thr; S['n_balls']=len(b); S['n_matches']=b.match_id.nunique(); S['hi_share']=b.hi.mean(); S['hi_n']=int(b.hi.sum())
S['meanLI']=b.li.mean()
b['phase']=pd.cut(b.over,[0,6,15,20],labels=['Powerplay (1-6)','Middle (7-15)','Death (16-20)'])
ph=b.groupby(['innings','phase'],observed=True).agg(meanLI=('li','mean'),pct_high=('hi','mean'),n=('li','size')).round(4); S['phase']=ph
S['rpb']=(b[b.hi].tot.mean(),b[~b.hi].tot.mean()); S['wk']=(b[b.hi].wk.mean(),b[~b.hi].wk.mean())
S['wpdist']=((b[b.hi].wp0-.5).abs().mean(),(b[~b.hi].wp0-.5).abs().mean())
h2=b[b.hi&(b.innings==2)]; S['rrr_med_hi']=h2.rrr.median(); S['rrr_med_lo']=b[~b.hi&(b.innings==2)].rrr.median()
S['balls_left_hi']=b[b.hi].balls_left.median(); S['balls_left_lo']=b[~b.hi].balls_left.median()
S['wk_lost_hi']=b[b.hi].wk_before.mean(); S['wk_lost_lo']=b[~b.hi].wk_before.mean()
S['ko']=(b[b.knock_out==1].hi.mean(),b[b.knock_out==0].hi.mean())
S['ct']=b.groupby('ctype').hi.mean().to_dict(); S['inn_hi']=b.groupby('innings').hi.mean().to_dict()
S['wp_mid_share_hi']=((b[b.hi].wp0>0.3)&(b[b.hi].wp0<0.7)).mean(); S['wp_mid_share_lo']=((b[~b.hi].wp0>0.3)&(b[~b.hi].wp0<0.7)).mean()
from sklearn.metrics import log_loss,brier_score_loss
S['ll']=log_loss(b.y,np.clip(b.wp0,1e-4,1-1e-4)); S['brier']=brier_score_loss(b.y,b.wp0); S['brier_base']=brier_score_loss(b.y,np.full(len(b),b.y.mean()))
S['brier_inn']={i:brier_score_loss(b[b.innings==i].y,b[b.innings==i].wp0) for i in (1,2)}
pickle.dump(S,open('/home/claude/out/stats.pkl','wb'))
for k,v in S.items(): print(k,v)
# ---- fig1 leverage by over
fig,ax=plt.subplots(figsize=(7.2,3.6),dpi=200)
g=b.groupby(['innings','over']).li.mean().unstack(0)
ax.plot(g.index,g[1],color=GRAY,lw=2,marker='o',ms=4,label='Innings 1 (setting a total)')
ax.plot(g.index,g[2],color=BLUE,lw=2,marker='o',ms=4,label='Innings 2 (chasing)')
ax.axhline(thr,color=ORANGE,lw=1.2,ls='--'); ax.text(1,thr+0.0006,f'High-pressure threshold ({thr:.4f}, 75th percentile of ball leverage)',color='#52514e',fontsize=8)
ax.set_xlabel('Over'); ax.set_ylabel('Mean leverage (expected win-probability swing per ball)'); ax.set_xticks(range(1,21)); ax.legend(frameon=False,loc='upper left',bbox_to_anchor=(0,0.88))
ax.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v,_:f'{v*100:.1f}%'))
plt.tight_layout(); plt.savefig(out+'fig1_leverage.png'); plt.close()
# ---- fig2 calibration
fig,ax=plt.subplots(figsize=(4.6,4.2),dpi=200)
cal=pd.DataFrame({'p':b.wp0,'y':b.y}); cal['bin']=pd.cut(cal.p,np.linspace(0,1,11)); c=cal.groupby('bin',observed=True).agg(p=('p','mean'),y=('y','mean'),n=('y','size'))
ax.plot([0,1],[0,1],color='#b8b7b0',lw=1,ls='--'); ax.plot(c.p,c.y,color=BLUE,lw=2,marker='o',ms=6)
ax.set_xlabel('Predicted win probability (out-of-sample)'); ax.set_ylabel('Observed win rate'); ax.set_xlim(0,1); ax.set_ylim(0,1)
plt.tight_layout(); plt.savefig(out+'fig2_calibration.png'); plt.close()
# ---- fig3/4 dumbbells
def dumb(role,fname,xl,exp_col,act_col,base_col,lowgood):
    t=tabs[role].head(10).iloc[::-1]; fig,ax=plt.subplots(figsize=(7.2,4.6),dpi=200); y=np.arange(len(t))
    for i,(idx,r) in enumerate(t.iterrows()):
        ax.plot([r[exp_col],r[act_col]],[i,i],color='#cfcec8',lw=2.5,zorder=1)
    ax.scatter(t[exp_col],y,s=60,facecolor='white',edgecolor=GRAY,lw=1.8,zorder=3,label='Expected for an average player in the same situations')
    ax.scatter(t[act_col],y,s=64,color=BLUE,zorder=4,label='Actual under pressure')
    ax.scatter(t[base_col],y,s=46,marker='D',color=ORANGE,zorder=3,label='Same player, ordinary situations')
    ax.set_yticks(y); ax.set_yticklabels(t.name,color=INK); ax.set_xlabel(xl); ax.grid(axis='x',color='#ececea',lw=.8); ax.set_axisbelow(True)
    ax.legend(frameon=False,fontsize=8,loc='upper center',bbox_to_anchor=(0.5,-0.14),ncol=1)
    plt.tight_layout(); plt.savefig(out+fname,bbox_inches='tight'); plt.close()
dumb('bat','fig3_batters.png','Strike rate (runs per 100 balls)','P_xSR','P_SR','B_SR',False)
dumb('bowl','fig4_bowlers.png','Economy rate (runs per over) - lower is better','P_xeco','P_eco','B_eco',True)
# ---- fig5 rank uncertainty
fig,axs=plt.subplots(1,2,figsize=(9,4.4),dpi=200,sharex=True)
for ax,role,title in zip(axs,('bat','bowl'),('Batters','Bowlers')):
    m=rob[role]['main'].head(10).iloc[::-1]; q10=rob[role]['boot_q10'].reindex(m.index); q90=rob[role]['boot_q90'].reindex(m.index); med=rob[role]['boot_med'].reindex(m.index)
    y=np.arange(len(m)); ax.hlines(y,q10,q90,color='#cfcec8',lw=5,zorder=1); ax.scatter(med,y,color=BLUE,s=40,zorder=3)
    ax.scatter(m['rank'],y,marker='D',color=ORANGE,s=34,zorder=4)
    ax.set_yticks(y); ax.set_yticklabels(m.name,color=INK,fontsize=9); ax.set_title(title,loc='left',color=INK,fontsize=11); ax.set_xlabel('Rank among eligible players (1 = best)'); ax.invert_xaxis() if False else None
    ax.grid(axis='x',color='#ececea',lw=.8); ax.set_axisbelow(True); ax.set_xlim(0,60)
axs[0].scatter([],[],color=BLUE,s=40,label='Median bootstrap rank'); axs[0].scatter([],[],marker='D',color=ORANGE,s=34,label='Final rank'); axs[0].hlines([],[],[],color='#cfcec8',lw=5,label='Middle 80% of 200 resamples')
fig.legend(*axs[0].get_legend_handles_labels(),frameon=False,loc='lower center',ncol=3,fontsize=8,bbox_to_anchor=(0.5,-0.03))
plt.tight_layout(rect=(0,0.05,1,1)); plt.savefig(out+'fig5_rank_uncertainty.png',bbox_inches='tight'); plt.close()
print('ok')
