import pandas as pd, numpy as np, glob
d='/home/claude/data/'
b=pd.concat([pd.read_csv(f,low_memory=False) for f in sorted(glob.glob(d+'bbb*.csv'))],ignore_index=True)
m=pd.read_csv(d+'matches.csv'); c=pd.read_csv(d+'comps.csv')
m=m.merge(c[['comp_id','comp_name','match_format','season']],on='comp_id',how='left')
m['ctype']=np.where(m.comp_name.str.contains('IPL'),1,np.where(m.match_format=='T20I',0,2))
b=b[b.innings.isin([1,2])].copy()
b['tot']=b.runs+b.extras1_runs+b.extras_2_runs
b=b.sort_values(['match_id','innings','innings_ball_num']).reset_index(drop=True)
b['legal']=~b.extras_type.isin(['wide','Overstep','other'])
b['wk']=b.is_wicket.astype(int)
g=b.groupby(['match_id','innings'])
b['runs_before']=g.tot.cumsum()-b.tot
b['wk_before']=g.wk.cumsum()-b.wk
b['legal_before']=g.legal.cumsum()-b.legal.astype(int)
b['is_last']=g.cumcount(ascending=False)==0
tot=g.tot.sum().unstack()  # innings totals
cnt=g.size().unstack()
mm=pd.DataFrame({'r1':tot[1],'r2':tot[2],'n2':cnt[2]})
mm=m.merge(mm,left_on='match_id',right_index=True,how='inner')
# exclusions
ex=pd.Series('',index=mm.index)
ex[mm.revised_target.notna()|mm.first_inn_revised_overs.notna()|mm.second_inn_revised_overs.notna()]='revised'
ex[mm.r2.isna()]='no2nd'
ex[(ex=='')&(mm.r1==mm.r2)]='tie'
chase_win=(mm.r2>mm.r1)
# consistency with recorded winner
bat2=b[b.innings==2].groupby('match_id').batting_team_id.first()
mm['bat2']=mm.match_id.map(bat2)
cons=(mm.win_team_id==mm.bat2)==chase_win
ex[(ex=='')&(~cons)]='winner_mismatch'
mm['excl']=ex; mm['chase_win']=chase_win.astype(int)
print(mm.excl.value_counts())
print(mm[mm.excl=='winner_mismatch'][['match_id','r1','r2','result','win_team_id','bat2']].head(10))
keep=mm[mm.excl==''].copy()
print('kept matches',len(keep), keep.ctype.value_counts().to_dict())
# venue mean 1st-inn score, leave-one-out, shrunk to comp-type mean
keep['r1']=keep.r1.astype(float)
ct_mean=keep.groupby('ctype').r1.mean()
vs=keep.groupby('venue_id').r1.agg(['sum','count'])
k=keep.merge(vs,left_on='venue_id',right_index=True)
k['ctm']=k.ctype.map(ct_mean)
K=5
k['venue_par']=((k['sum']-k.r1)+K*k.ctm)/((k['count']-1)+K)
keep=k.set_index('match_id')
b=b[b.match_id.isin(keep.index)].copy()
for col in ['r1','r2','chase_win','ctype','venue_par','match_date','season','knock_out','stage','comp_name']:
    b[col]=b.match_id.map(keep[col])
b['target']=b.r1+1
b['balls_left']=120-b.legal_before
b['runs_needed']=np.where(b.innings==2,b.target-b.runs_before,np.nan)
b['crr']=b.runs_before/np.maximum(b.legal_before,1)*6
b['rrr']=np.where(b.innings==2,b.runs_needed/np.maximum(b.balls_left,1)*6,np.nan)
b['y']=np.where(b.innings==2,b.chase_win,1-b.chase_win)  # batting side wins
b.to_pickle('/home/claude/out/states.pkl'); keep.to_pickle('/home/claude/out/matches_kept.pkl')
print(b.shape, b.match_id.nunique(), b.groupby('innings').size().to_dict())
print(b.balls_left.min(), (b.runs_needed<=0).sum())
# max legal balls
print(b.groupby(['match_id','innings']).legal.sum().describe())
