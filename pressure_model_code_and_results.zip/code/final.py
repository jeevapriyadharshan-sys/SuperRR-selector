import sys; sys.path.insert(0,"/home/claude/work")
import pandas as pd, numpy as np, pickle
import rating2 as R
b0,thr=R.load(0.75); RB=R.build(b0)
rows=pd.read_pickle('/home/claude/out/rows.pkl'); rows['hi']=rows.li>=thr
MH,MU=200,18
fin={}
for role,sgn in (('bat',-1),('bowl',1)):
    d=RB[role]; el,_=R.rate(d,sgn,min_hi=MH,min_units=MU); el['name']=d.groupby('pid').name.last()
    fin[role]=el
    print(role,len(el)); print(el[['name','nH','nU','score','zL','zR','zC']].head(12).round(3).to_string())
# supporting stats from raw data
bt=rows[(~rows.wide)&rows.legal]
def batstats(pid):
    x=bt[bt.striker_id==pid]; o={}
    for lab,m in (('P',x.hi),('B',~x.hi)):
        y=x[m]; o[lab+'_balls']=len(y); o[lab+'_SR']=100*y.runs.sum()/len(y); o[lab+'_dis']=100*y.dis_bat.sum()/len(y); o[lab+'_xSR']=100*y.er.sum()/len(y)
    return o
def bowlstats(pid):
    x=rows[rows.bowler_id==pid]; o={}
    for lab,m in (('P',x.hi),('B',~x.hi)):
        y=x[m]; lg=y.legal.sum()
        o[lab+'_balls']=int(lg); o[lab+'_eco']=6*y.tot.sum()/lg; o[lab+'_xeco']=6*y.er.where(y.legal,0).sum()/lg; o[lab+'_wk']=100*y.dis_bowl.sum()/lg
        o[lab+'_dot']=100*((y.tot==0)&y.legal).sum()/lg
    return o
rob=pickle.load(open('/home/claude/out/robust2.pkl','rb'))
tabs={}
for role,f in (('bat',batstats),('bowl',bowlstats)):
    el=fin[role].head(15)
    t=pd.DataFrame({p:f(p) for p in el.index}).T; t.insert(0,'name',el.name); t['score']=el.score; t['L']=el.L; t['Res']=el.Res; t['C']=el.C; t['nU']=el.nU
    t['unit_success']=el.Craw
    tabs[role]=t
    pd.set_option('display.width',250); print(t.round(2).to_string())
pickle.dump((fin,tabs,thr),open('/home/claude/out/final.pkl','wb'))
