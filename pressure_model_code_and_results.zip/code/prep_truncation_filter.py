import pandas as pd, numpy as np
b=pd.read_pickle('/home/claude/out/states.pkl')
g=b.groupby(['match_id','innings']).agg(L=('legal','sum'),w=('wk','sum'),r=('tot','sum'),tg=('target','first')).reset_index()
bad=g[(g.L<120)&(g.w<10)&~((g.innings==2)&(g.r>=g.tg))]
badm=set(bad.match_id)
b=b[~b.match_id.isin(badm)].copy()
print(len(badm), b.match_id.nunique(), len(b))
b.to_pickle('/home/claude/out/states.pkl')
mk=pd.read_pickle('/home/claude/out/matches_kept.pkl'); mk=mk[~mk.index.isin(badm)]; mk.to_pickle('/home/claude/out/matches_kept.pkl')
print(mk.ctype.value_counts().to_dict(), mk.chase_win.mean())
