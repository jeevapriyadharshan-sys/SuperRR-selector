import sys; sys.path.insert(0,"/home/claude/work")
import pandas as pd, numpy as np
LAM=7.74; WL,WR,WC=0.5,0.25,0.25
def load(q=0.75):
    b=pd.read_pickle('/home/claude/out/rows.pkl'); thr=b.li.quantile(q); b['hi']=b.li>=thr; return b,thr
def shr(df,idc,vc,min_n=60):
    g=df.groupby(idc)[vc].agg(['mean','size']); s2=df[vc].var(); big=g[g['size']>=min_n]
    tau2=max(big['mean'].var()-np.mean(s2/big['size']),1e-7)
    return g['mean']*tau2/(tau2+s2/g['size'])
def build(b,adjust=True):
    b=b.copy(); leg=b.legal.values
    b['er_e']=np.where(leg,b.er,0.0); b['pw_e']=np.where(leg,b.pw,0.0)
    b['conc']=b.tot-b.er_e                      # runs conceded above expected (bowler view, + = bad for bowler)
    b['wk_b']=b.dis_bowl-b.pw_e                 # wickets above expected for bowler
    bt=b[b.legal].copy(); bt['rae']=bt.tot-bt.er; bt['dae']=bt.dis_bat-bt.pw
    if adjust:
        bq_c=shr(b,'bowler_id','conc'); bq_w=shr(b,'bowler_id','wk_b')   # bowler general quality
        bat_r=shr(bt,'striker_id','rae'); bat_d=shr(bt,'striker_id','dae')
        bt['rae']-=bt.bowler_id.map(bq_c).fillna(0); bt['dae']-=bt.bowler_id.map(bq_w).fillna(0)
        b['conc']-=b.striker_id.map(bat_r).fillna(0); b['wk_b']-=b.striker_id.map(bat_d).fillna(0)
    out={}
    bt['pid']=bt.striker_id; bt['name']=bt.striker_name; bt['rae_g']=bt.rae; bt['dae_g']=bt.dae; bt['net']=bt.rae-LAM*bt.dae
    out['bat']=bt
    b['pid']=b.bowler_id; b['name']=b.bowler_name; b['rae_g']=-b.conc; b['dae_g']=b.wk_b; b['net']=-b.conc+LAM*b.wk_b
    out['bowl']=b
    cols=['match_id','innings','pid','name','hi','rae_g','dae_g','net','date','season','ctype','over','li']
    res={}
    for k,d in out.items():
        d=d[cols].copy()
        for h in (True,False):
            m=d.hi==h
            for c in ('rae_g','dae_g','net'): d.loc[m,c]-=d.loc[m,c].mean()
        res[k]=d
    return res
def eb(x,se2):
    tau2=max(np.var(x)-np.mean(se2),1e-8); return x*tau2/(tau2+se2),tau2
def rate(d,sgn,w=None,min_hi=200,min_units=18,unit_min=4,weights=(WL,WR,WC)):
    d=d.copy(); d['w']=1.0 if w is None else d.match_id.map(w).fillna(0).values
    d=d[d.w>0]
    for c in ('rae_g','dae_g','net'): d['w_'+c]=d.w*d[c]
    hi=d[d.hi]; lo=d[~d.hi]
    agg=lambda x:x.groupby('pid').agg(n=('w','sum'),r=('w_rae_g','sum'),e=('w_dae_g','sum'),t=('w_net','sum'))
    H=agg(hi); Lw=agg(lo)
    u=hi.groupby(['pid','match_id','innings']).agg(n=('w','sum'),s=('w_net','sum'),wm=('w','max')).reset_index()
    u=u[u.n>=unit_min*u.wm]; u['pos']=(u.s>0)*u.wm
    U=u.groupby('pid').agg(nU=('wm','sum'),pos=('pos','sum'))
    t=H.join(Lw,lsuffix='H',rsuffix='L',how='left').join(U,how='left').fillna(0)
    el=t[(t.nH>=min_hi)&(t.nU>=min_units)].copy()
    out={}
    vH={c:np.average(hi[c]**2,weights=hi.w) for c in ('rae_g','dae_g','net')}
    vL={c:np.average(lo[c]**2,weights=lo.w) for c in ('rae_g','dae_g','net')}
    mp={'r':'rae_g','e':'dae_g','t':'net'}
    for k,c in mp.items():
        xH=el[k+'H']/el.nH; xL=np.where(el.nL>0,el[k+'L']/el.nL.clip(lower=1),0)
        el['xH_'+k]=xH; el['xL_'+k]=xL
        el['L_'+k],_=eb(xH.values,(vH[c]/el.nH).values)
        el['R_'+k],_=eb((xH-xL).values,(vH[c]/el.nH+vL[c]/el.nL.clip(lower=1)).values)
    # combine components with wicket worth: net = rae + sgn*LAM*dae  (sgn=-1 batting, +1 bowling) -> use separately shrunk parts
    el['L']=el.L_r+sgn*LAM*el.L_e; el['Res']=el.R_r+sgn*LAM*el.R_e
    rawL=(el.xH_r+sgn*LAM*el.xH_e); rawR=((el.xH_r-el.xL_r)+sgn*LAM*(el.xH_e-el.xL_e))
    p0=u.pos.sum()/u.wm.sum(); el['Craw']=el.pos/el.nU
    Cs,tauC=eb((el.Craw-p0).values,(p0*(1-p0)/el.nU).values); el['C']=p0+Cs
    el['zL']=(el.L-el.L.mean())/rawL.std(); el['zR']=(el.Res-el.Res.mean())/rawR.std(); el['zC']=(el.C-p0)/el.Craw.std()
    wl,wr,wc=weights; el['score']=wl*el.zL+wr*el.zR+wc*el.zC
    el['rank']=el.score.rank(ascending=False,method='first')
    el['xH']=rawL; el['xL']=el.xL_r+sgn*LAM*el.xL_e
    return el.sort_values('score',ascending=False),dict(p0=p0)
if __name__=='__main__':
    b,thr=load(); R=build(b)
    for role,s in (('bat',-1),('bowl',1)):
        d=R[role]; el,info=rate(d,s); el['name']=d.groupby('pid').name.last()
        print(role,len(el)); print(el[['name','nH','nU','xH_r','xH_e','xL','L','Res','C','zL','zR','zC','score']].head(15).round(3).to_string())
