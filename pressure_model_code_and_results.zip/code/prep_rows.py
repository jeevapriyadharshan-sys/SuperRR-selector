import pandas as pd, numpy as np
b=pd.read_pickle('/home/claude/out/model_out.pkl')
FL=0.005
b['li_d']=np.maximum(b.li,FL)
dt=b.dismissal_type.fillna('')
uncred_bowl=b.wk.eq(1)&dt.isin(['RunOut','Retire Out','Obstracting the field','Obstructing the field'])
uncred_bat=b.wk.eq(1)&((b.dismissed_player_id!=b.striker_id)|dt.eq('Retire Out'))
dW=b.wp1-b.wp0; dWn=b.wp_nw-b.wp0
b['dW_bat']=np.where(uncred_bat,dWn,dW)
b['dW_bowl']=-np.where(uncred_bowl,dWn,dW)
b['V_bat']=np.clip(b.dW_bat/b.li_d,-5,5)
b['V_bowl']=np.clip(b.dW_bowl/b.li_d,-5,5)
b['date']=pd.to_datetime(b.match_date)
b['over']=(b.legal_before//6)+1
b['wide']=b.extras_type.eq('wide')
b['dis_bat']=((b.wk==1)&~uncred_bat).astype(int)
b['dis_bowl']=((b.wk==1)&~uncred_bowl).astype(int)
b.to_pickle('/home/claude/out/rows.pkl')
print(b[['V_bat','V_bowl','dW_bat','dW_bowl']].describe().round(4))
print('mean dW overall',dW.mean(), 'corr', np.corrcoef(b.V_bat,b.V_bowl)[0,1])
