import pandas as pd, numpy as np, time
from sklearn.ensemble import HistGradientBoostingClassifier as HGB
from sklearn.model_selection import GroupKFold
from sklearn.metrics import log_loss, brier_score_loss
b=pd.read_pickle('/home/claude/out/states.pkl').reset_index(drop=True)
COLS=['inn','lb','wk','runs','crr','need','rrr','target','vp','ct']
def F(inn,lb,wk,runs,target,vp,ct):
    inn=np.asarray(inn); lb=np.asarray(lb,float); wk=np.asarray(wk,float); runs=np.asarray(runs,float)
    target=np.asarray(target,float); vp=np.asarray(vp,float); ct=np.asarray(ct,float)
    crr=runs/np.maximum(lb,1)*6
    need=np.where(inn==2,target-runs,np.nan)
    rrr=need/np.maximum(120-lb,1)*6
    tg=np.where(inn==2,target,np.nan)
    return pd.DataFrame({'inn':inn,'lb':lb,'wk':wk,'runs':runs,'crr':crr,'need':need,'rrr':rrr,'target':tg,'vp':vp,'ct':ct})[COLS]
class Sub:
    def __init__(self,cols,**kw): self.cols=cols; self.m=HGB(**kw)
    def fit(self,X,y): self.m.fit(X[self.cols],y); self.classes_=self.m.classes_; return self
    def predict_proba(self,X): return self.m.predict_proba(X[self.cols])
KW=dict(max_iter=120,learning_rate=0.05,max_leaf_nodes=8,min_samples_leaf=1500,l2_regularization=10.0,random_state=0)
C1=['lb','wk','runs','ct']; C2=['lb','wk','need','rrr','ct']
class Mono(Sub):
    def __init__(self,cols,mono,**kw): self.cols=cols; self.m=HGB(monotonic_cst=mono,**kw)
MON1=[0,-1,1,0]; MON2=[0,-1,-1,-1,0]; CO=['inn','lb','wk','runs','crr','rrr','ct']
def mk_old(): return HGB(max_iter=250,learning_rate=0.05,max_leaf_nodes=15,min_samples_leaf=300,l2_regularization=5.0,random_state=0)
RV=np.array([0,1,2,3,4,6]); NO=7
def wp(M1,M2,inn,lb,wk,runs,target,vp,ct):
    inn=np.asarray(inn);lb=np.asarray(lb);wk=np.asarray(wk);runs=np.asarray(runs);target=np.asarray(target)
    vp=np.asarray(vp);ct=np.asarray(ct)
    out=np.zeros(len(inn))
    # innings 2
    i2=inn==2
    done=i2&(runs>=target); out[done]=1.0
    dead=i2&~done&((wk>=10)|(lb>=120)); out[dead]=0.0
    live2=i2&~done&~dead
    if live2.any(): out[live2]=M2.predict_proba(F(inn[live2],lb[live2],wk[live2],runs[live2],target[live2],vp[live2],ct[live2]))[:,1]
    i1=inn==1
    end1=i1&((wk>=10)|(lb>=120))
    if end1.any():
        tg=runs[end1]+1
        out[end1]=1-M2.predict_proba(F(np.full(end1.sum(),2),np.zeros(end1.sum()),np.zeros(end1.sum()),np.zeros(end1.sum()),tg,vp[end1],ct[end1]))[:,1]
    live1=i1&~end1
    if live1.any(): out[live1]=M1.predict_proba(F(inn[live1],lb[live1],wk[live1],runs[live1],target[live1],vp[live1],ct[live1]))[:,1]
    return out
def outcome_y(r):
    t=np.minimum(r.tot.values,7); w=r.wk.values==1
    y=np.where(t<=4,t,np.where(t==5,4,6)); y=np.where(y==6,5,y)  # classes 0-4 ->0..4 ; 6 ->5
    return np.where(w,6,y)
tg=b.target.values
X=F(b.innings,b.legal_before,b.wk_before,b.runs_before,tg,b.venue_par,b.ctype)
N=len(b)
wp0=np.zeros(N); wp_nw=np.zeros(N); li=np.zeros(N); er=np.zeros(N); pw=np.zeros(N)
fold=np.zeros(N,int)
gkf=GroupKFold(n_splits=5)
t0=time.time()
yb=b.y.values
legal=b.legal.values
yo=outcome_y(b)
for f,(tr,te) in enumerate(gkf.split(X,groups=b.match_id)):
    fold[te]=f
    tr1=tr[b.innings.values[tr]==1]; tr2=tr[b.innings.values[tr]==2]
    M1=Mono(C1,MON1,**KW).fit(X.iloc[tr1],yb[tr1]); M2=Mono(C2,MON2,**KW).fit(X.iloc[tr2],yb[tr2])
    trl=tr[legal[tr]]
    MO=Sub(CO,**KW).fit(X.iloc[trl],yo[trl])
    inn=b.innings.values[te]; lb=b.legal_before.values[te]; wk=b.wk_before.values[te]; rn=b.runs_before.values[te]
    tgt=tg[te]; vp=b.venue_par.values[te]; ct=b.ctype.values[te]
    wp0[te]=wp(M1,M2,inn,lb,wk,rn,tgt,vp,ct)
    # no-wicket actual-runs counterpart
    adv=legal[te].astype(int)
    wp_nw[te]=wp(M1,M2,inn,lb+adv,wk,rn+b.tot.values[te],tgt,vp,ct)
    P=MO.predict_proba(X.iloc[te]); cls=list(MO.classes_)
    Pf=np.zeros((len(te),7)); 
    for j,cj in enumerate(cls): Pf[:,cj]=P[:,j]
    lii=np.zeros(len(te)); ere=np.zeros(len(te))
    for o in range(6):
        w_h=wp(M1,M2,inn,lb+1,wk,rn+RV[o],tgt,vp,ct)
        lii+=Pf[:,o]*np.abs(w_h-wp0[te]); ere+=Pf[:,o]*RV[o]
    w_h=wp(M1,M2,inn,lb+1,wk+1,rn,tgt,vp,ct)
    lii+=Pf[:,6]*np.abs(w_h-wp0[te])
    li[te]=lii; er[te]=ere; pw[te]=Pf[:,6]
    print('fold',f,round(time.time()-t0),flush=True)
b['wp0']=wp0; b['wp_nw']=wp_nw; b['li']=li; b['er']=er; b['pw']=pw; b['fold']=fold
# WP after = next row's wp0 in same innings; last: inn1 -> 1 - first row inn2 wp0 ; inn2 -> y
nxt=b.groupby(['match_id','innings']).wp0.shift(-1)
first2=b[b.innings==2].groupby('match_id').wp0.first()
last=b.is_last.values
nxt=np.where(last&(b.innings.values==1),1-b.match_id.map(first2).values,nxt)
nxt=np.where(last&(b.innings.values==2),b.y.values,nxt)
b['wp1']=nxt
# for last ball of innings-1 w/ nw counterpart etc keep as is
print('WP model: logloss',log_loss(yb,np.clip(wp0,1e-4,1-1e-4)),'brier',brier_score_loss(yb,wp0),'base brier',brier_score_loss(yb,np.full(N,yb.mean())))
for inn in (1,2):
    mk_=b.innings.values==inn
    print(inn,'brier',brier_score_loss(yb[mk_],wp0[mk_]),'AUC-ish') 
cal=pd.DataFrame({'p':wp0,'y':yb}); cal['bin']=pd.cut(cal.p,np.linspace(0,1,11)); print(cal.groupby('bin',observed=True).agg(p=('p','mean'),y=('y','mean'),n=('y','size')))
print(b.li.describe(), b.li.quantile([.5,.75,.9,.95]))
b.to_pickle('/home/claude/out/model_out.pkl')
